import React from 'react';

const Footer = () => {

    return (
        <footer className='d-flex flex-row justify-content-center align-items-center p-2 footer-container text-white'>
            Powered by Avalanche ©2020-2022
        </footer>
    );
}

export default Footer;
